define("b034ff07-d400-40d1-882b-4de44506d831_0.0.1", ["@microsoft/decorators","@microsoft/sp-listview-extensibility","@microsoft/sp-http"], (__WEBPACK_EXTERNAL_MODULE__138__, __WEBPACK_EXTERNAL_MODULE__249__, __WEBPACK_EXTERNAL_MODULE__272__) => { return /******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 929:
/*!*************************************************************!*\
  !*** ./lib/extensions/customNewItem/generatedFormSchema.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GENERATED_FORM_CSS: () => (/* binding */ GENERATED_FORM_CSS),
/* harmony export */   GENERATED_FORM_FIELDS: () => (/* binding */ GENERATED_FORM_FIELDS),
/* harmony export */   GENERATED_FORM_TITLE: () => (/* binding */ GENERATED_FORM_TITLE)
/* harmony export */ });
var GENERATED_FORM_TITLE = "zxzx";
var GENERATED_FORM_CSS = "body {\r\n            margin: 0;\r\n            padding: 24px 32px;\r\n            background: #ececec;\r\n            font-family: Arial, sans-serif;\r\n            color: #1f2937;\r\n        }\r\n\r\n        .form-wrapper {\r\n            max-width: 1024px;\r\n            margin: 0 auto;\r\n            background: transparent;\r\n            border: 0;\r\n            border-radius: 0;\r\n            padding: 0;\r\n            box-shadow: none;\r\n        }\r\n\r\n        .form-title {\r\n            margin: 0 0 18px;\r\n            font-size: 46px;\r\n            line-height: 1.1;\r\n            font-weight: 600;\r\n            text-align: center;\r\n            color: #111827;\r\n        }\r\n\r\n        /* Match app style closer than default Form.io theme */\r\n        .formio-component+.formio-component {\r\n            margin-top: 0.85rem;\r\n        }\r\n\r\n        .formio-component-label {\r\n            margin-bottom: 0.25rem;\r\n            color: #4b5563;\r\n            font-size: 12px;\r\n            font-weight: 500;\r\n        }\r\n\r\n        .form-control {\r\n            min-height: 42px;\r\n            border: 1px solid #d7d7d7;\r\n            border-radius: 2px;\r\n            box-shadow: none !important;\r\n        }\r\n\r\n        .btn-primary,\r\n        .btn.btn-primary {\r\n            background-color: #25bfb4 !important;\r\n            border-color: #25bfb4 !important;\r\n            color: #fff !important;\r\n            min-width: 180px;\r\n        }\r\n\r\n        .formio-errors,\r\n        .alert-danger {\r\n            display: none !important;\r\n        }\n\n.demo-ok {\r\n            color: blue;\r\n        }";
var GENERATED_FORM_FIELDS = [
    {
        "key": "title",
        "label": "Title",
        "type": "textfield",
        "customClass": "demo-ok"
    },
    {
        "key": "detail",
        "label": "detail",
        "type": "textfield",
        "customClass": "demo-ok"
    },
    {
        "key": "des",
        "label": "des",
        "type": "textfield",
        "customClass": ""
    },
    {
        "key": "image",
        "label": "image",
        "type": "customFileUpload",
        "customClass": ""
    }
];


/***/ }),

/***/ 138:
/*!****************************************!*\
  !*** external "@microsoft/decorators" ***!
  \****************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__138__;

/***/ }),

/***/ 272:
/*!*************************************!*\
  !*** external "@microsoft/sp-http" ***!
  \*************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__272__;

/***/ }),

/***/ 249:
/*!*******************************************************!*\
  !*** external "@microsoft/sp-listview-extensibility" ***!
  \*******************************************************/
/***/ ((module) => {

module.exports = __WEBPACK_EXTERNAL_MODULE__249__;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!*****************************************************************!*\
  !*** ./lib/extensions/customNewItem/CustomNewItemCommandSet.js ***!
  \*****************************************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _microsoft_decorators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @microsoft/decorators */ 138);
/* harmony import */ var _microsoft_decorators__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_microsoft_decorators__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _microsoft_sp_listview_extensibility__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @microsoft/sp-listview-extensibility */ 249);
/* harmony import */ var _microsoft_sp_listview_extensibility__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_listview_extensibility__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-http */ 272);
/* harmony import */ var _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./generatedFormSchema */ 929);
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (undefined && undefined.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var CustomNewItemCommandSet = /** @class */ (function (_super) {
    __extends(CustomNewItemCommandSet, _super);
    function CustomNewItemCommandSet() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CustomNewItemCommandSet.prototype.onInit = function () {
        console.log("✅ CustomNewItemCommandSet initialized");
        var command = this.tryGetCommand('COMMAND_1');
        if (command) {
            command.visible = true;
        }
        var editCommand = this.tryGetCommand('COMMAND_2');
        if (editCommand) {
            editCommand.visible = false;
        }
        return Promise.resolve();
    };
    CustomNewItemCommandSet.prototype.onListViewUpdated = function (event) {
        var _a, _b;
        var editCommand = this.tryGetCommand('COMMAND_2');
        if (editCommand) {
            var selectedCount = (_b = (_a = event === null || event === void 0 ? void 0 : event.selectedRows) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0;
            editCommand.visible = selectedCount === 1;
        }
    };
    CustomNewItemCommandSet.prototype.onExecute = function (event) {
        var _a, _b;
        if (event.itemId === 'COMMAND_1') {
            this.openCustomModal('new').catch(function (e) { return console.error(e); });
        }
        if (event.itemId === 'COMMAND_2') {
            var selected = (_b = (_a = this.context.listView) === null || _a === void 0 ? void 0 : _a.selectedRows) === null || _b === void 0 ? void 0 : _b[0];
            var idRaw = selected === null || selected === void 0 ? void 0 : selected.getValueByName('ID');
            var itemId = typeof idRaw === 'number' ? idRaw : Number(idRaw);
            if (!isNaN(itemId)) {
                this.openCustomModal('edit', itemId).catch(function (e) { return console.error(e); });
            }
        }
    };
    CustomNewItemCommandSet.prototype.getListFieldInternalNames = function (listName) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function () {
            var webUrl, fieldsRes, fieldsJson, fields, titleToInternal, i, f, title, internal;
            return __generator(this, function (_d) {
                switch (_d.label) {
                    case 0:
                        webUrl = this.context.pageContext.web.absoluteUrl;
                        return [4 /*yield*/, this.context.spHttpClient.get("".concat(webUrl, "/_api/web/lists/getbytitle('").concat(listName, "')/fields?$select=Title,InternalName,TypeAsString&$filter=Hidden eq false and ReadOnlyField eq false"), _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__.SPHttpClient.configurations.v1)];
                    case 1:
                        fieldsRes = _d.sent();
                        return [4 /*yield*/, fieldsRes.json()];
                    case 2:
                        fieldsJson = _d.sent();
                        fields = (_c = (_b = (_a = fieldsJson === null || fieldsJson === void 0 ? void 0 : fieldsJson.d) === null || _a === void 0 ? void 0 : _a.results) !== null && _b !== void 0 ? _b : fieldsJson === null || fieldsJson === void 0 ? void 0 : fieldsJson.value) !== null && _c !== void 0 ? _c : [];
                        titleToInternal = {};
                        for (i = 0; i < fields.length; i++) {
                            f = fields[i];
                            title = String((f === null || f === void 0 ? void 0 : f.Title) || '').toLowerCase();
                            internal = String((f === null || f === void 0 ? void 0 : f.InternalName) || '');
                            if (title && internal) {
                                titleToInternal[title] = internal;
                            }
                            if (internal) {
                                titleToInternal[internal.toLowerCase()] = internal;
                            }
                        }
                        return [2 /*return*/, { titleToInternal: titleToInternal }];
                }
            });
        });
    };
    CustomNewItemCommandSet.prototype.getCurrentListName = function () {
        var _a;
        var listTitle = (_a = this.context.pageContext.list) === null || _a === void 0 ? void 0 : _a.title;
        return listTitle && listTitle.trim() ? listTitle : "Products";
    };
    CustomNewItemCommandSet.prototype.resolveInternalName = function (titleToInternal, candidates) {
        for (var i = 0; i < candidates.length; i++) {
            var key = (candidates[i] || '').trim().toLowerCase();
            if (key && titleToInternal[key]) {
                return titleToInternal[key];
            }
        }
        return undefined;
    };
    CustomNewItemCommandSet.prototype.openCustomModal = function (mode, editItemId) {
        return __awaiter(this, void 0, void 0, function () {
            var modal, host, pageUrlEl;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        modal = document.createElement("div");
                        modal.innerHTML = "\n    <div id=\"glozicModal\" style=\"\n      position:fixed;\n      top:0; left:0;\n      width:100%; height:100%;\n      background:rgba(0,0,0,0.5);\n      display:flex;\n      align-items:center;\n      justify-content:center;\n      z-index:9999;\n    \">\n      <style>".concat(_generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_CSS, "</style>\n      <div style=\"background:#fff; border-radius:10px; padding:14px; width:920px; max-height:92vh; overflow:auto;\">\n        <h2 style=\"margin: 4px 8px 12px; font-size:28px; font-weight:600;\">").concat(mode === 'edit' ? '✏️ Edit Product' : '📦 Add Product', "</h2>\n        <div class=\"form-wrapper\">\n          <h1 class=\"form-title\">").concat(this.escapeHtml(_generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_TITLE), "</h1>\n          <div id=\"glozic-form\">\n            ").concat(this.renderDynamicFields(), "\n          </div>\n        </div>\n        <div style=\"display:flex; justify-content:flex-end; gap:10px; margin-top:12px;\">\n          <button style=\"padding:10px 18px; border:none; border-radius:6px; cursor:pointer; font-weight:600; background:#eee;\" id=\"cancelBtn\">Cancel</button>\n          <button style=\"padding:10px 18px; border:none; border-radius:6px; cursor:pointer; font-weight:600; background:#25bfb4; color:#fff;\" id=\"saveBtn\">").concat(mode === 'edit' ? 'Update Product' : 'Save Product', "</button>\n        </div>\n      </div>\n    </div>\n  ");
                        document.body.appendChild(modal);
                        host = document.getElementById("glozicModal");
                        if (host) {
                            host.dataset.glozicMode = mode;
                            if (editItemId !== undefined)
                                host.dataset.glozicItemId = String(editItemId);
                        }
                        this.bindFormEvents();
                        pageUrlEl = this.getFieldElement('pageUrl');
                        if (pageUrlEl) {
                            pageUrlEl.value = window.location.href;
                        }
                        if (!(mode === 'edit' && editItemId !== undefined)) return [3 /*break*/, 2];
                        return [4 /*yield*/, this.loadItemIntoForm(editItemId)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2 /*return*/];
                }
            });
        });
    };
    CustomNewItemCommandSet.prototype.getFieldElement = function (key) {
        return document.getElementById("glozic-field-".concat(key));
    };
    CustomNewItemCommandSet.prototype.getFieldValue = function (key) {
        var _a;
        var el = this.getFieldElement(key);
        return el ? ((_a = el.value) !== null && _a !== void 0 ? _a : '') : '';
    };
    CustomNewItemCommandSet.prototype.setFieldValue = function (key, value) {
        var el = this.getFieldElement(key);
        if (el) {
            el.value = value;
        }
    };
    CustomNewItemCommandSet.prototype.renderDynamicFields = function () {
        var _this = this;
        var fields = _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS.filter(function (field) { return field.type !== 'button'; });
        return fields.map(function (field) {
            var safeLabel = _this.escapeHtml(field.label || field.key);
            var safeKey = _this.escapeHtml(field.key);
            var safeCustomClass = _this.escapeHtml(field.customClass || '');
            var typeLower = field.type.toLowerCase();
            var isDescription = typeLower === 'textarea' || field.key.toLowerCase() === 'description';
            var isNumber = field.type.toLowerCase() === 'number';
            var isFile = typeLower.indexOf('file') !== -1 || typeLower.indexOf('image') !== -1;
            var wrapperClass = "formio-component ".concat(safeCustomClass).trim();
            var labelHtml = "<div class=\"formio-component-label\">".concat(safeLabel, "</div>");
            var classNames = "form-control".trim();
            var wrapperStart = "<div class=\"".concat(wrapperClass, "\">");
            var wrapperEnd = "</div>";
            if (isDescription) {
                return "".concat(wrapperStart).concat(labelHtml, "<textarea id=\"glozic-field-").concat(safeKey, "\" class=\"").concat(classNames, "\" style=\"min-height:86px;\"></textarea>").concat(wrapperEnd);
            }
            if (isFile) {
                return "".concat(wrapperStart).concat(labelHtml, "<input id=\"glozic-field-").concat(safeKey, "\" type=\"file\" />").concat(wrapperEnd);
            }
            var type = isNumber ? 'number' : 'text';
            return "".concat(wrapperStart).concat(labelHtml, "<input id=\"glozic-field-").concat(safeKey, "\" type=\"").concat(type, "\" class=\"").concat(classNames, "\" />").concat(wrapperEnd);
        }).join('');
    };
    CustomNewItemCommandSet.prototype.escapeHtml = function (value) {
        return value
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    };
    CustomNewItemCommandSet.prototype.bindFormEvents = function () {
        var _this = this;
        var _a, _b;
        (_a = document.getElementById("cancelBtn")) === null || _a === void 0 ? void 0 : _a.addEventListener("click", function () {
            var _a;
            (_a = document.getElementById("glozicModal")) === null || _a === void 0 ? void 0 : _a.remove();
        });
        (_b = document.getElementById("saveBtn")) === null || _b === void 0 ? void 0 : _b.addEventListener("click", function () {
            _this.saveProduct().catch(function (e) { return console.error(e); });
        });
    };
    CustomNewItemCommandSet.prototype.getModalModeAndItemId = function () {
        var _a, _b;
        var host = document.querySelector('#glozicModal');
        var mode = (((_a = host === null || host === void 0 ? void 0 : host.dataset) === null || _a === void 0 ? void 0 : _a.glozicMode) === 'edit' ? 'edit' : 'new');
        var idRaw = (_b = host === null || host === void 0 ? void 0 : host.dataset) === null || _b === void 0 ? void 0 : _b.glozicItemId;
        var parsed = idRaw ? Number(idRaw) : undefined;
        return { mode: mode, itemId: parsed !== undefined && !isNaN(parsed) ? parsed : undefined };
    };
    CustomNewItemCommandSet.prototype.loadItemIntoForm = function (itemId) {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var webUrl, listName, internals, selectFields, i, field, typeLower, internal, res, data, item, i, field, typeLower, keyLower, labelLower, internal, raw;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        webUrl = this.context.pageContext.web.absoluteUrl;
                        listName = this.getCurrentListName();
                        return [4 /*yield*/, this.getListFieldInternalNames(listName)];
                    case 1:
                        internals = _b.sent();
                        selectFields = ['Title'];
                        for (i = 0; i < _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS.length; i++) {
                            field = _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS[i];
                            typeLower = String(field.type || '').toLowerCase();
                            if (typeLower.indexOf('file') !== -1 || typeLower.indexOf('image') !== -1) {
                                continue;
                            }
                            internal = this.resolveInternalName(internals.titleToInternal, [field.key, field.label]);
                            if (internal && selectFields.indexOf(internal) === -1) {
                                selectFields.push(internal);
                            }
                        }
                        return [4 /*yield*/, this.context.spHttpClient.get("".concat(webUrl, "/_api/web/lists/getbytitle('").concat(listName, "')/items(").concat(itemId, ")?$select=").concat(selectFields.join(',')), _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__.SPHttpClient.configurations.v1)];
                    case 2:
                        res = _b.sent();
                        return [4 /*yield*/, res.json()];
                    case 3:
                        data = _b.sent();
                        item = (_a = data === null || data === void 0 ? void 0 : data.d) !== null && _a !== void 0 ? _a : data;
                        for (i = 0; i < _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS.length; i++) {
                            field = _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS[i];
                            typeLower = String(field.type || '').toLowerCase();
                            if (typeLower.indexOf('file') !== -1 || typeLower.indexOf('image') !== -1) {
                                continue;
                            }
                            keyLower = String(field.key || '').toLowerCase();
                            labelLower = String(field.label || '').toLowerCase();
                            if (keyLower === 'pageurl' || labelLower === 'pageurl') {
                                this.setFieldValue(field.key, window.location.href);
                                continue;
                            }
                            internal = this.resolveInternalName(internals.titleToInternal, [field.key, field.label]);
                            if (!internal) {
                                continue;
                            }
                            raw = item === null || item === void 0 ? void 0 : item[internal];
                            this.setFieldValue(field.key, raw !== undefined && raw !== null ? String(raw) : "");
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    CustomNewItemCommandSet.prototype.saveProduct = function () {
        var _a;
        return __awaiter(this, void 0, void 0, function () {
            var titleKey, titleValue, fileInput, webUrl, listName, modalInfo, internals, itemBody, i, field, typeLower, value, keyLower, labelLower, internal, parsed, isEdit, url, response, errText, data, _b, itemId, file, safeFileName, uploadRes, uploadErr, error_1;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0:
                        titleKey = this.findFieldKey(['title', 'producttitle']);
                        titleValue = titleKey ? this.getFieldValue(titleKey) : '';
                        fileInput = this.getFileInput();
                        webUrl = this.context.pageContext.web.absoluteUrl;
                        _c.label = 1;
                    case 1:
                        _c.trys.push([1, 12, , 13]);
                        listName = this.getCurrentListName();
                        modalInfo = this.getModalModeAndItemId();
                        return [4 /*yield*/, this.getListFieldInternalNames(listName)];
                    case 2:
                        internals = _c.sent();
                        itemBody = {
                            Title: titleValue
                        };
                        for (i = 0; i < _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS.length; i++) {
                            field = _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS[i];
                            typeLower = String(field.type || '').toLowerCase();
                            if (typeLower.indexOf('file') !== -1 || typeLower.indexOf('image') !== -1) {
                                continue;
                            }
                            value = this.getFieldValue(field.key).trim();
                            if (value === '') {
                                continue;
                            }
                            keyLower = String(field.key || '').toLowerCase();
                            labelLower = String(field.label || '').toLowerCase();
                            if (keyLower === 'title' || labelLower === 'title' || keyLower === 'producttitle') {
                                itemBody.Title = value;
                                continue;
                            }
                            if (keyLower === 'pageurl' || labelLower === 'pageurl') {
                                continue;
                            }
                            internal = this.resolveInternalName(internals.titleToInternal, [field.key, field.label]);
                            if (!internal) {
                                continue;
                            }
                            if (typeLower === 'number') {
                                parsed = Number(value);
                                if (!isNaN(parsed)) {
                                    itemBody[internal] = parsed;
                                }
                            }
                            else {
                                itemBody[internal] = value;
                            }
                        }
                        isEdit = modalInfo.mode === 'edit' && modalInfo.itemId !== undefined;
                        url = isEdit
                            ? "".concat(webUrl, "/_api/web/lists/getbytitle('").concat(listName, "')/items(").concat(modalInfo.itemId, ")")
                            : "".concat(webUrl, "/_api/web/lists/getbytitle('").concat(listName, "')/items");
                        return [4 /*yield*/, this.context.spHttpClient.post(url, _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__.SPHttpClient.configurations.v1, {
                                headers: __assign({ "Accept": "application/json;odata=nometadata", "Content-Type": "application/json;odata=nometadata", "odata-version": "" }, (isEdit ? { "IF-MATCH": "*", "X-HTTP-Method": "MERGE" } : {})),
                                body: JSON.stringify(itemBody)
                            })];
                    case 3:
                        response = _c.sent();
                        if (!!response.ok) return [3 /*break*/, 5];
                        return [4 /*yield*/, response.text()];
                    case 4:
                        errText = _c.sent();
                        console.error("🔥 SHAREPOINT ERROR (create item):", errText);
                        throw new Error(errText);
                    case 5:
                        if (!isEdit) return [3 /*break*/, 6];
                        _b = undefined;
                        return [3 /*break*/, 8];
                    case 6: return [4 /*yield*/, response.json()];
                    case 7:
                        _b = _c.sent();
                        _c.label = 8;
                    case 8:
                        data = _b;
                        itemId = isEdit ? modalInfo.itemId : data === null || data === void 0 ? void 0 : data.Id;
                        if (!(!isEdit && fileInput && fileInput.files && fileInput.files.length > 0)) return [3 /*break*/, 11];
                        file = fileInput.files[0];
                        safeFileName = encodeURIComponent(file.name.replace(/'/g, "''"));
                        return [4 /*yield*/, this.context.spHttpClient.post("".concat(webUrl, "/_api/web/lists/getbytitle('").concat(listName, "')/items(").concat(itemId, ")/AttachmentFiles/add(FileName='").concat(safeFileName, "')"), _microsoft_sp_http__WEBPACK_IMPORTED_MODULE_2__.SPHttpClient.configurations.v1, {
                                headers: {
                                    "Accept": "application/json;odata=nometadata",
                                    "Content-Type": "application/octet-stream",
                                    "odata-version": ""
                                },
                                body: file
                            })];
                    case 9:
                        uploadRes = _c.sent();
                        if (!!uploadRes.ok) return [3 /*break*/, 11];
                        return [4 /*yield*/, uploadRes.text()];
                    case 10:
                        uploadErr = _c.sent();
                        console.error("🔥 SHAREPOINT ERROR (upload):", uploadErr);
                        throw new Error(uploadErr);
                    case 11:
                        alert(isEdit ? "✅ Product updated!" : "✅ Product saved!");
                        (_a = document.getElementById("glozicModal")) === null || _a === void 0 ? void 0 : _a.remove();
                        location.reload();
                        return [3 /*break*/, 13];
                    case 12:
                        error_1 = _c.sent();
                        console.error(error_1);
                        return [3 /*break*/, 13];
                    case 13: return [2 /*return*/];
                }
            });
        });
    };
    CustomNewItemCommandSet.prototype.findFieldKey = function (keywords) {
        var lowered = keywords.map(function (k) { return k.toLowerCase(); });
        for (var i = 0; i < _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS.length; i++) {
            var field = _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS[i];
            var key = (field.key || '').toLowerCase();
            var label = (field.label || '').toLowerCase();
            for (var j = 0; j < lowered.length; j++) {
                var keyword = lowered[j];
                if (key.indexOf(keyword) !== -1 || label.indexOf(keyword) !== -1) {
                    return field.key;
                }
            }
        }
        return undefined;
    };
    CustomNewItemCommandSet.prototype.getFileInput = function () {
        for (var i = 0; i < _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS.length; i++) {
            var field = _generatedFormSchema__WEBPACK_IMPORTED_MODULE_3__.GENERATED_FORM_FIELDS[i];
            var type = (field.type || '').toLowerCase();
            if (type.indexOf('file') !== -1 || type.indexOf('image') !== -1) {
                return document.getElementById("glozic-field-".concat(field.key));
            }
        }
        return null;
    };
    __decorate([
        _microsoft_decorators__WEBPACK_IMPORTED_MODULE_0__.override
    ], CustomNewItemCommandSet.prototype, "onInit", null);
    __decorate([
        _microsoft_decorators__WEBPACK_IMPORTED_MODULE_0__.override
    ], CustomNewItemCommandSet.prototype, "onListViewUpdated", null);
    __decorate([
        _microsoft_decorators__WEBPACK_IMPORTED_MODULE_0__.override
    ], CustomNewItemCommandSet.prototype, "onExecute", null);
    return CustomNewItemCommandSet;
}(_microsoft_sp_listview_extensibility__WEBPACK_IMPORTED_MODULE_1__.BaseListViewCommandSet));
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomNewItemCommandSet);

})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});;
//# sourceMappingURL=custom-new-item-command-set.js.map