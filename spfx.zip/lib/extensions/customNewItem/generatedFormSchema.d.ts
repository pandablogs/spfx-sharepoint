export interface IGeneratedFormField {
    key: string;
    label: string;
    type: string;
    customClass?: string;
}
export declare const GENERATED_FORM_TITLE: string;
export declare const GENERATED_FORM_CSS: string;
export declare const GENERATED_FORM_FIELDS: IGeneratedFormField[];
//# sourceMappingURL=generatedFormSchema.d.ts.map