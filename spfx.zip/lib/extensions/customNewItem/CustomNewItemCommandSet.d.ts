import { BaseListViewCommandSet, IListViewCommandSetListViewUpdatedParameters } from '@microsoft/sp-listview-extensibility';
export interface ICustomNewItemCommandSetProperties {
}
export default class CustomNewItemCommandSet extends BaseListViewCommandSet<ICustomNewItemCommandSetProperties> {
    onInit(): Promise<void>;
    onListViewUpdated(event: IListViewCommandSetListViewUpdatedParameters): void;
    onExecute(event: {
        itemId: string;
    }): void;
    private getListFieldInternalNames;
    private getCurrentListName;
    private resolveInternalName;
    private openCustomModal;
    private getFieldElement;
    private getFieldValue;
    private setFieldValue;
    private renderDynamicFields;
    private escapeHtml;
    private bindFormEvents;
    private getModalModeAndItemId;
    private loadItemIntoForm;
    private saveProduct;
    private findFieldKey;
    private getFileInput;
}
//# sourceMappingURL=CustomNewItemCommandSet.d.ts.map